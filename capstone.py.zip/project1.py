# RBAC Security System - Python Implementation
import csv
from datetime import datetime

class RBACSystem:
    def __init__(self):
        self.roles = {}
        self.permissions = {}
        self.users = {}
        self.role_permissions = {}
        self.user_roles = {}
        
    def create_role(self, role_name):
        if role_name in self.roles:
            print(f"Role '{role_name}' already exists!")
            return False
        self.roles[role_name] = {"created": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        self.role_permissions[role_name] = []
        print(f"Role '{role_name}' created successfully!")
        return True
    
    def create_permission(self, perm_name, description=""):
        if perm_name in self.permissions:
            print(f"Permission '{perm_name}' already exists!")
            return False
        self.permissions[perm_name] = {"description": description}
        print(f"Permission '{perm_name}' created successfully!")
        return True
    
    def assign_permission_to_role(self, role_name, perm_name):
        if role_name not in self.roles:
            print(f"Role '{role_name}' does not exist!")
            return False
        if perm_name not in self.permissions:
            print(f"Permission '{perm_name}' does not exist!")
            return False
        if perm_name in self.role_permissions[role_name]:
            print(f"Permission '{perm_name}' already assigned to role '{role_name}'!")
            return False
        
        self.role_permissions[role_name].append(perm_name)
        print(f"Permission '{perm_name}' assigned to role '{role_name}'!")
        return True
    
    def create_user(self, username):
        if username in self.users:
            print(f"User '{username}' already exists!")
            return False
        self.users[username] = {"created": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        self.user_roles[username] = None
        print(f"User '{username}' created successfully!")
        return True
    
    def assign_user_to_role(self, username, role_name):
        if username not in self.users:
            print(f"User '{username}' does not exist!")
            return False
        if role_name not in self.roles:
            print(f"Role '{role_name}' does not exist!")
            return False
        
        self.user_roles[username] = role_name
        print(f"User '{username}' assigned to role '{role_name}'!")
        return True
    
    def delete_user(self, username):
        if username not in self.users:
            print(f"User '{username}' does not exist!")
            return False
        
        del self.users[username]
        del self.user_roles[username]
        print(f"User '{username}' deleted successfully!")
        return True
    
    def remove_user_from_role(self, username):
        if username not in self.users:
            print(f"User '{username}' does not exist!")
            return False
        
        self.user_roles[username] = None
        print(f"User '{username}' removed from their role!")
        return True
    
    def get_user_permissions(self, username):
        if username not in self.users:
            return []
        
        role = self.user_roles.get(username)
        if role and role in self.role_permissions:
            return self.role_permissions[role]
        return []
    
    def import_users_from_file(self, filename):
        try:
            with open(filename, 'r') as file:
                reader = csv.DictReader(file)
                count = 0
                for row in reader:
                    username = row.get('username', '').strip()
                    role = row.get('role', '').strip()
                    
                    if username:
                        if username not in self.users:
                            self.create_user(username)
                        if role and role in self.roles:
                            self.assign_user_to_role(username, role)
                        count += 1
                
                print(f"\nSuccessfully imported {count} users from '{filename}'!")
                return True
        except FileNotFoundError:
            print(f"File '{filename}' not found!")
            return False
        except Exception as e:
            print(f"Error importing file: {e}")
            return False
    
    def export_users_to_file(self, filename):
        try:
            with open(filename, 'w', newline='') as file:
                fieldnames = ['username', 'role', 'permissions']
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                
                writer.writeheader()
                for username, user_data in self.users.items():
                    role = self.user_roles.get(username, 'None')
                    perms = ', '.join(self.get_user_permissions(username))
                    
                    writer.writerow({
                        'username': username,
                        'role': role if role else 'None',
                        'permissions': perms if perms else 'None'
                    })
                
                print(f"\nSuccessfully exported users to '{filename}'!")
                return True
        except Exception as e:
            print(f"Error exporting file: {e}")
            return False
    
    def display_all_roles(self):
        print("\n" + "="*50)
        print("ALL ROLES")
        print("="*50)
        if not self.roles:
            print("No roles created yet.")
        else:
            for role_name in self.roles:
                perms = self.role_permissions.get(role_name, [])
                print(f"\nRole: {role_name}")
                print(f"  Permissions: {', '.join(perms) if perms else 'None'}")
    
    def display_all_permissions(self):
        print("\n" + "="*50)
        print("ALL PERMISSIONS")
        print("="*50)
        if not self.permissions:
            print("No permissions created yet.")
        else:
            for perm_name, perm_data in self.permissions.items():
                desc = perm_data.get('description', '')
                print(f"\nPermission: {perm_name}")
                if desc:
                    print(f"  Description: {desc}")
    
    def display_all_users(self):
        print("\n" + "="*50)
        print("ALL USERS")
        print("="*50)
        if not self.users:
            print("No users created yet.")
        else:
            for username, user_data in self.users.items():
                role = self.user_roles.get(username, 'None')
                perms = self.get_user_permissions(username)
                print(f"\nUser: {username}")
                print(f"  Role: {role if role else 'None'}")
                print(f"  Permissions: {', '.join(perms) if perms else 'None'}")


def main():
    rbac = RBACSystem()
    
    rbac.create_permission("read", "View content")
    rbac.create_permission("write", "Create and edit content")
    rbac.create_permission("read_write", "View and edit content")
    rbac.create_permission("delete", "Delete content")
    
    while True:
        print("\n" + "="*50)
        print("RBAC SECURITY SYSTEM - MAIN MENU")
        print("="*50)
        print("1.  Create Role")
        print("2.  Assign Permission to Role")
        print("3.  Create User")
        print("4.  Assign User to Role")
        print("5.  Delete User")
        print("6.  Remove User from Role")
        print("7.  Import Users from CSV File")
        print("8.  Export Users to CSV File")
        print("9.  Display All Roles")
        print("10. Display All Permissions")
        print("11. Display All Users")
        print("12. Exit")
        print("="*50)
        
        choice = input("\nEnter your choice (1-12): ").strip()
        
        if choice == "1":
            role_name = input("Enter role name (e.g., Marketing, Finance): ").strip()
            if role_name:
                rbac.create_role(role_name)
        
        elif choice == "2":
            rbac.display_all_roles()
            rbac.display_all_permissions()
            role_name = input("\nEnter role name: ").strip()
            perm_name = input("Enter permission name: ").strip()
            if role_name and perm_name:
                rbac.assign_permission_to_role(role_name, perm_name)
        
        elif choice == "3":
            username = input("Enter username: ").strip()
            if username:
                rbac.create_user(username)
        
        elif choice == "4":
            rbac.display_all_users()
            rbac.display_all_roles()
            username = input("\nEnter username: ").strip()
            role_name = input("Enter role name: ").strip()
            if username and role_name:
                rbac.assign_user_to_role(username, role_name)
        
        elif choice == "5":
            rbac.display_all_users()
            username = input("\nEnter username to delete: ").strip()
            if username:
                confirm = input(f"Are you sure you want to delete '{username}'? (yes/no): ").strip().lower()
                if confirm == 'yes':
                    rbac.delete_user(username)
        
        elif choice == "6":
            rbac.display_all_users()
            username = input("\nEnter username to remove from role: ").strip()
            if username:
                rbac.remove_user_from_role(username)
        
        elif choice == "7":
            filename = input("Enter CSV filename to import (e.g., users.csv): ").strip()
            if filename:
                print("\nCSV Format: username,role")
                print("Example: john_doe,Marketing")
                rbac.import_users_from_file(filename)
        
        elif choice == "8":
            filename = input("Enter CSV filename to export (e.g., export.csv): ").strip()
            if filename:
                rbac.export_users_to_file(filename)
        
        elif choice == "9":
            rbac.display_all_roles()
        
        elif choice == "10":
            rbac.display_all_permissions()
        
        elif choice == "11":
            rbac.display_all_users()
        
        elif choice == "12":
            print("\nThank you for using RBAC Security System!")
            break
        
        else:
            print("\nInvalid choice! Please enter a number between 1 and 12.")
        
        input("\nPress Enter to continue...")


if __name__ == "__main__":
    main()
""" 
## Features

- Create and manage roles (Marketing, Finance, Admin, etc.)
- Pre-defined permissions: read, write, read_write, delete
- Assign permissions to roles
- Create users with just usernames
- Assign users to roles
- Delete users from the system
- Remove users from their roles
- Import users from CSV files
- Export users and their permissions to CSV files
- View all roles, permissions, and users

## CSV File Format for Import

Create a file called `users.csv` with this format:

```
username,role
john_doe,Marketing
jane_smith,Finance
bob_jones,Admin
```

Make sure the roles exist in the system before importing!
 """